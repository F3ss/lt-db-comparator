# Prometheus Statistics

Консольная программа на Python для сбора метрик из Prometheus, расчета агрегатов и записи истории запусков в CSV.

## Требования

- Python 3.11+
- только стандартная библиотека Python

## Структура проекта

Код разложен по слоям, но без лишних фасадов и дублирующих файлов:

- [domain](/d:/projects/prometheus-statistics/prometheus_statistics/domain) — доменные модели, enum'ы и чистые вычисления
- [application/service.py](/d:/projects/prometheus-statistics/prometheus_statistics/application/service.py) — orchestration сценария сбора статистики
- [infrastructure/config_loader.py](/d:/projects/prometheus-statistics/prometheus_statistics/infrastructure/config_loader.py) — чтение и валидация TOML
- [infrastructure/provider.py](/d:/projects/prometheus-statistics/prometheus_statistics/infrastructure/provider.py) — работа с Prometheus HTTP
- [infrastructure/csv_history.py](/d:/projects/prometheus-statistics/prometheus_statistics/infrastructure/csv_history.py) — чтение и запись CSV истории
- [presentation/cli.py](/d:/projects/prometheus-statistics/prometheus_statistics/presentation/cli.py) — CLI entry point
- [metric_catalog](/d:/projects/prometheus-statistics/prometheus_statistics/metric_catalog) — каталог групп метрик и шаблонов запросов

## Конфиг

Используется TOML-конфиг. Пример есть в [config.example.toml](/d:/projects/prometheus-statistics/config.example.toml).

Основные поля:

- `run.system_name` — имя тестируемой системы
- `run.timestamp` — timestamp запуска в секундах
- `run.start` — начало диапазона сбора
- `run.end` — конец диапазона сбора
- `run.history_columns` — сколько запусков хранить в CSV
- `run.output_csv` — путь к итоговому CSV
- `collection.step_seconds` — шаг range-запроса
- `source.base_url` — адрес Prometheus
- `selection.groups` / `selection.metric_ids` — группы и отдельные метрики
- `selection.variables` — общие переменные шаблонов запросов
- `selection.group_variables.<group>` — переменные для конкретной группы
- `selection.metric_variables.<metric_id>` — override для конкретной метрики

Для `kubernetes_containers` сейчас поддерживаются:

- `namespace` — regex для label `namespace`, по умолчанию `.*`
- `pod_regex` — regex для label `pod`, по умолчанию `.*`

При рендеринге запросов переменные применяются в таком порядке:

- дефолты группы/запроса
- `selection.variables`
- `selection.group_variables.<group>`
- `selection.metric_variables.<metric_id>`

Неиспользуемые переменные в конфиге допустимы: это позволяет заранее держать общие значения под будущие группы.

## Каталог метрик

Группы и запросы разнесены по отдельному пакету:

- базовые спецификации: [specs.py](/d:/projects/prometheus-statistics/prometheus_statistics/metric_catalog/specs.py)
- каталог и резолвинг выбора: [catalog.py](/d:/projects/prometheus-statistics/prometheus_statistics/metric_catalog/catalog.py)
- конкретные группы: [groups](/d:/projects/prometheus-statistics/prometheus_statistics/metric_catalog/groups)
- доменные модели: [domain](/d:/projects/prometheus-statistics/prometheus_statistics/domain)

Основные классы:

- `MetricGroupSpec` — группа запросов
- `MetricQuerySpec` — отдельный шаблон запроса внутри группы
- `MetricCatalog` — реестр и рендеринг итоговых метрик

Чтобы добавить новую группу, достаточно создать новый класс группы, вложенные классы запросов и зарегистрировать группу в `DEFAULT_METRIC_CATALOG`.

## Запуск

```bash
python -m prometheus_statistics --config config.example.toml
```

После успешного выполнения программа выведет путь к обновленному CSV-файлу.

## Что попадает в CSV

Для каждой метрики сохраняются:

- `p90`
- `p95`
- `p99`
- `max`
- `min`

История обновляется так:

- новая итерация всегда записывается во вторую колонку
- старые колонки сдвигаются вправо
- если появляется новая метрика, в старых колонках для нее пишется `null`
- если в новой итерации метрика отсутствует, в новой колонке для нее пишется `null`
- старые колонки удаляются при превышении `history_columns`

## Тесты

```bash
python -m unittest discover -s tests -v
```

Отдельный e2e с реальным Prometheus запускается только при наличии переменной среды
`PROMETHEUS_E2E_CONFIG`, которая должна указывать на TOML-конфиг для реального окружения.

PowerShell:

```powershell
$env:PROMETHEUS_E2E_CONFIG = ".\config.real.toml"
python -m unittest tests.test_e2e_real_prometheus -v
```
