# Prometheus Statistics

Консольная программа на Python для сбора метрик из Prometheus, расчета агрегатов и записи истории запусков в CSV.

## Требования

- Python 3.11+
- только стандартная библиотека Python

## Конфиг

Используется TOML-конфиг. Пример есть в [config.example.toml](/d:/projects/prometheus-statistics/config.example.toml).

Основные поля:

- `run.system_name` — имя тестируемой системы
- `run.timestamp` — timestamp запуска в секундах
- `run.start` — начало диапазона сбора
- `run.end` — конец диапазона сбора
- `run.history_columns` — сколько запусков хранить в CSV
- `run.output_csv` — путь к итоговому CSV
- `collection.step_seconds` — шаг range-запроса
- `source.base_url` — адрес Prometheus
- `selection.groups` / `selection.metric_ids` — группы и отдельные метрики

## Запуск

```bash
python -m prometheus_statistics --config config.example.toml
```

После успешного выполнения программа выведет путь к обновленному CSV-файлу.

## Что попадает в CSV

Для каждой метрики сохраняются:

- `p90`
- `p95`
- `p99`
- `max`
- `min`

История обновляется так:

- новая итерация всегда записывается во вторую колонку
- старые колонки сдвигаются вправо
- если появляется новая метрика, в старых колонках для нее пишется `null`
- если в новой итерации метрика отсутствует, в новой колонке для нее пишется `null`
- старые колонки удаляются при превышении `history_columns`

## Тесты

```bash
python -m unittest discover -s tests -v
```
