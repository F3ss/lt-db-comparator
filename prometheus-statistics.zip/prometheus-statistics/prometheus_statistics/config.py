"""Configuration loading and validation."""

from __future__ import annotations

from pathlib import Path
from typing import Any
import tomllib

from .exceptions import ConfigError
from .metric_groups import DEFAULT_METRIC_CATALOG, MetricCatalog
from .models import (
    AppConfig,
    CollectionConfig,
    MetricGroup,
    RunConfig,
    SelectionConfig,
    SourceConfig,
    SourceKind,
)


class ConfigLoader:
    """Load and validate an application configuration from a TOML file."""

    def __init__(self, catalog: MetricCatalog | None = None) -> None:
        """Initialize the loader with the metric catalog used for validation."""

        self._catalog = catalog or DEFAULT_METRIC_CATALOG

    def load(self, path: Path) -> AppConfig:
        """Load, validate and convert a TOML config file into domain models."""

        try:
            with path.open("rb") as file_obj:
                raw_config = tomllib.load(file_obj)
        except FileNotFoundError as exc:
            raise ConfigError(f"Configuration file not found: {path}") from exc
        except tomllib.TOMLDecodeError as exc:
            raise ConfigError(f"Configuration file is not valid TOML: {exc}") from exc

        if not isinstance(raw_config, dict):
            raise ConfigError("Configuration root must be a TOML table.")

        run = self._parse_run_section(path, self._require_table(raw_config, "run"))
        collection = self._parse_collection_section(self._require_table(raw_config, "collection"))
        source = self._parse_source_section(self._require_table(raw_config, "source"))
        selection = self._parse_selection_section(self._require_table(raw_config, "selection"))

        return AppConfig(run=run, collection=collection, source=source, selection=selection)

    def _parse_run_section(self, config_path: Path, section: dict[str, Any]) -> RunConfig:
        system_name = self._require_non_empty_string(section, "system_name")
        timestamp = self._require_non_negative_int(section, "timestamp")
        start = self._require_non_negative_int(section, "start")
        end = self._require_non_negative_int(section, "end")
        history_columns = self._optional_int(section, "history_columns", 10)
        output_csv = self._require_non_empty_string(section, "output_csv")

        if start > end:
            raise ConfigError("'run.start' must be less than or equal to 'run.end'.")
        if history_columns < 1:
            raise ConfigError("'run.history_columns' must be greater than or equal to 1.")

        output_path = Path(output_csv)
        if not output_path.is_absolute():
            output_path = config_path.parent / output_path

        return RunConfig(
            system_name=system_name,
            timestamp=timestamp,
            start=start,
            end=end,
            history_columns=history_columns,
            output_csv=output_path,
        )

    def _parse_collection_section(self, section: dict[str, Any]) -> CollectionConfig:
        step_seconds = self._optional_int(section, "step_seconds", 15)
        if step_seconds < 1:
            raise ConfigError("'collection.step_seconds' must be greater than or equal to 1.")
        return CollectionConfig(step_seconds=step_seconds)

    def _parse_source_section(self, section: dict[str, Any]) -> SourceConfig:
        kind_value = self._require_non_empty_string(section, "kind")
        base_url = self._require_non_empty_string(section, "base_url")
        timeout_seconds = self._optional_int(section, "timeout_seconds", 10)

        if timeout_seconds < 1:
            raise ConfigError("'source.timeout_seconds' must be greater than or equal to 1.")

        try:
            kind = SourceKind(kind_value)
        except ValueError as exc:
            supported = ", ".join(item.value for item in SourceKind)
            raise ConfigError(
                f"Unsupported source kind '{kind_value}'. Supported values: {supported}."
            ) from exc

        return SourceConfig(kind=kind, base_url=base_url, timeout_seconds=timeout_seconds)

    def _parse_selection_section(self, section: dict[str, Any]) -> SelectionConfig:
        raw_groups = section.get("groups", [])
        raw_metric_ids = section.get("metric_ids", [])

        if not isinstance(raw_groups, list):
            raise ConfigError("'selection.groups' must be a list.")
        if not isinstance(raw_metric_ids, list):
            raise ConfigError("'selection.metric_ids' must be a list.")

        groups: list[MetricGroup] = []
        for raw_group in raw_groups:
            if not isinstance(raw_group, str):
                raise ConfigError("Each item in 'selection.groups' must be a string.")
            try:
                groups.append(MetricGroup(raw_group))
            except ValueError as exc:
                supported = ", ".join(group.value for group in MetricGroup)
                raise ConfigError(
                    f"Unknown metric group '{raw_group}'. Supported values: {supported}."
                ) from exc

        metric_ids: list[str] = []
        for raw_metric_id in raw_metric_ids:
            if not isinstance(raw_metric_id, str) or not raw_metric_id.strip():
                raise ConfigError("Each item in 'selection.metric_ids' must be a non-empty string.")
            if not self._catalog.has_metric(raw_metric_id):
                raise ConfigError(f"Unknown metric id '{raw_metric_id}'.")
            metric_ids.append(raw_metric_id)

        if not groups and not metric_ids:
            raise ConfigError("At least one metric group or metric id must be specified.")

        return SelectionConfig(groups=groups, metric_ids=metric_ids)

    @staticmethod
    def _require_table(data: dict[str, Any], name: str) -> dict[str, Any]:
        value = data.get(name)
        if not isinstance(value, dict):
            raise ConfigError(f"Missing or invalid section '[{name}]'.")
        return value

    @staticmethod
    def _require_non_empty_string(section: dict[str, Any], key: str) -> str:
        value = section.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ConfigError(f"'{key}' must be a non-empty string.")
        return value.strip()

    @staticmethod
    def _require_non_negative_int(section: dict[str, Any], key: str) -> int:
        value = section.get(key)
        if isinstance(value, bool) or not isinstance(value, int):
            raise ConfigError(f"'{key}' must be an integer.")
        if value < 0:
            raise ConfigError(f"'{key}' must be greater than or equal to 0.")
        return value

    @staticmethod
    def _optional_int(section: dict[str, Any], key: str, default: int) -> int:
        value = section.get(key, default)
        if isinstance(value, bool) or not isinstance(value, int):
            raise ConfigError(f"'{key}' must be an integer.")
        return value

