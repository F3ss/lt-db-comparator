"""Metric catalog and selection logic."""

from __future__ import annotations

from dataclasses import dataclass

from .exceptions import MetricSelectionError
from .models import MetricDefinition, MetricGroup, SelectionConfig


@dataclass(frozen=True)
class MetricCatalog:
    """Registry of all known metrics grouped by enum values."""

    metrics_by_group: dict[MetricGroup, tuple[MetricDefinition, ...]]

    def __post_init__(self) -> None:
        metric_ids: set[str] = set()
        display_names: set[str] = set()

        for group, metrics in self.metrics_by_group.items():
            for metric in metrics:
                if metric.group is not group:
                    raise ValueError(
                        f"Metric '{metric.metric_id}' belongs to '{metric.group.value}', "
                        f"but is registered in '{group.value}'."
                    )
                if metric.metric_id in metric_ids:
                    raise ValueError(f"Duplicate metric id: {metric.metric_id}")
                if metric.display_name in display_names:
                    raise ValueError(f"Duplicate metric display name: {metric.display_name}")
                metric_ids.add(metric.metric_id)
                display_names.add(metric.display_name)

    def metrics_for_group(self, group: MetricGroup) -> tuple[MetricDefinition, ...]:
        """Return all metrics registered for the specified group."""

        return self.metrics_by_group.get(group, ())

    def get_metric(self, metric_id: str) -> MetricDefinition:
        """Return a metric definition by its identifier."""

        for metrics in self.metrics_by_group.values():
            for metric in metrics:
                if metric.metric_id == metric_id:
                    return metric
        raise MetricSelectionError(f"Unknown metric id: {metric_id}")

    def has_metric(self, metric_id: str) -> bool:
        """Return whether the catalog contains the specified metric identifier."""

        try:
            self.get_metric(metric_id)
        except MetricSelectionError:
            return False
        return True

    def resolve_selection(self, selection: SelectionConfig) -> list[MetricDefinition]:
        """Resolve the final ordered list of unique metrics from the selection config."""

        resolved: list[MetricDefinition] = []
        seen_ids: set[str] = set()

        for group in selection.groups:
            for metric in self.metrics_for_group(group):
                if metric.metric_id not in seen_ids:
                    resolved.append(metric)
                    seen_ids.add(metric.metric_id)

        for metric_id in selection.metric_ids:
            metric = self.get_metric(metric_id)
            if metric.metric_id not in seen_ids:
                resolved.append(metric)
                seen_ids.add(metric.metric_id)

        if not resolved:
            raise MetricSelectionError("Metric selection resolved to an empty metric list.")

        return resolved


DEFAULT_METRIC_CATALOG = MetricCatalog(
    metrics_by_group={
        MetricGroup.KUBERNETES_CONTAINERS: (
            MetricDefinition(
                metric_id="utils_cpu",
                display_name="Utils cpu",
                group=MetricGroup.KUBERNETES_CONTAINERS,
                query='sum(rate(container_cpu_usage_seconds_total{container="utils"}[5m]))',
            ),
            MetricDefinition(
                metric_id="utils_ram",
                display_name="Utils ram",
                group=MetricGroup.KUBERNETES_CONTAINERS,
                query='sum(container_memory_working_set_bytes{container="utils"})',
            ),
            MetricDefinition(
                metric_id="api_cpu",
                display_name="API cpu",
                group=MetricGroup.KUBERNETES_CONTAINERS,
                query='sum(rate(container_cpu_usage_seconds_total{container="api"}[5m]))',
            ),
            MetricDefinition(
                metric_id="api_ram",
                display_name="API ram",
                group=MetricGroup.KUBERNETES_CONTAINERS,
                query='sum(container_memory_working_set_bytes{container="api"})',
            ),
        ),
        MetricGroup.KAFKA_EXPORTER: (
            MetricDefinition(
                metric_id="kafka_group_lag",
                display_name="Kafka group lag",
                group=MetricGroup.KAFKA_EXPORTER,
                query="sum(kafka_consumergroup_lag)",
            ),
            MetricDefinition(
                metric_id="kafka_topic_partitions",
                display_name="Kafka topic partitions",
                group=MetricGroup.KAFKA_EXPORTER,
                query="sum(kafka_topic_partitions)",
            ),
        ),
    }
)

