"""Module entry point for `python -m prometheus_statistics`."""

from .cli import main


raise SystemExit(main())

