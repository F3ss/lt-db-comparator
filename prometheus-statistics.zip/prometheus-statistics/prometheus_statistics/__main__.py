"""Module entry point for `python -m prometheus_statistics`."""

from .presentation.cli import main


raise SystemExit(main())
