"""Metric catalog and selection resolution."""

from __future__ import annotations

from dataclasses import dataclass, replace
from itertools import product

from ..domain import MetricDefinition, MetricGroup, MetricQueryTemplate, SelectionConfig
from ..exceptions import MetricSelectionError
from .specs import MetricGroupSpec


@dataclass(frozen=True)
class MetricCatalog:
    """Registry of all known metric templates grouped by enum values."""

    templates_by_group: dict[MetricGroup, tuple[MetricQueryTemplate, ...]]

    def __post_init__(self) -> None:
        metric_ids: set[str] = set()
        display_names: set[str] = set()

        for group, templates in self.templates_by_group.items():
            for template in templates:
                if template.group is not group:
                    raise ValueError(
                        f"Metric '{template.metric_id}' belongs to '{template.group.value}', "
                        f"but is registered in '{group.value}'."
                    )
                if template.metric_id in metric_ids:
                    raise ValueError(f"Duplicate metric id: {template.metric_id}")
                if template.display_name in display_names:
                    raise ValueError(f"Duplicate metric display name: {template.display_name}")
                metric_ids.add(template.metric_id)
                display_names.add(template.display_name)

    @classmethod
    def from_group_specs(cls, *group_specs: type[MetricGroupSpec]) -> "MetricCatalog":
        """Build a catalog from metric group specification classes."""

        return cls(
            templates_by_group={
                group_spec.group: group_spec.build_templates() for group_spec in group_specs
            }
        )

    def metrics_for_group(
        self,
        group: MetricGroup,
        variables: dict[str, str] | None = None,
    ) -> tuple[MetricDefinition, ...]:
        """Return all rendered metrics registered for the specified group."""

        return tuple(
            template.render(variables) for template in self.templates_by_group.get(group, ())
        )

    def get_metric(
        self,
        metric_id: str,
        variables: dict[str, str] | None = None,
    ) -> MetricDefinition:
        """Return a rendered metric definition by its identifier."""

        return self.get_template(metric_id).render(variables)

    def get_template(self, metric_id: str) -> MetricQueryTemplate:
        """Return a metric query template by its identifier."""

        for templates in self.templates_by_group.values():
            for template in templates:
                if template.metric_id == metric_id:
                    return template
        raise MetricSelectionError(f"Unknown metric id: {metric_id}")

    def has_metric(self, metric_id: str) -> bool:
        """Return whether the catalog contains the specified metric identifier."""

        try:
            self.get_template(metric_id)
        except MetricSelectionError:
            return False
        return True

    def resolve_selection(self, selection: SelectionConfig) -> list[MetricDefinition]:
        """Resolve the final ordered list of unique metrics from the selection config."""

        resolved: list[MetricDefinition] = []
        seen_keys: set[tuple[str, str, str]] = set()

        for group in selection.groups:
            for template in self.templates_by_group.get(group, ()):
                for metric in self._render_metrics(template, selection):
                    key = (metric.metric_id, metric.display_name, metric.query)
                    if key not in seen_keys:
                        resolved.append(metric)
                        seen_keys.add(key)

        for metric_id in selection.metric_ids:
            template = self.get_template(metric_id)
            for metric in self._render_metrics(template, selection):
                key = (metric.metric_id, metric.display_name, metric.query)
                if key not in seen_keys:
                    resolved.append(metric)
                    seen_keys.add(key)

        if not resolved:
            raise MetricSelectionError("Metric selection resolved to an empty metric list.")

        return resolved

    def _render_metrics(
        self,
        template: MetricQueryTemplate,
        selection: SelectionConfig,
    ) -> list[MetricDefinition]:
        variables = self._resolve_variables(template, selection)
        expanded_variants = self._expand_variable_variants(template, variables)

        metrics: list[MetricDefinition] = []
        for rendered_variables, display_suffix in expanded_variants:
            metric = template.render(rendered_variables)
            if display_suffix:
                metric = replace(metric, display_name=f"{metric.display_name} {display_suffix}")
            metrics.append(metric)
        return metrics

    @staticmethod
    def _expand_variable_variants(
        template: MetricQueryTemplate,
        variables: dict[str, str],
    ) -> list[tuple[dict[str, str], str]]:
        varying_variable_names = [
            variable_name
            for variable_name in template.required_variables()
            if len(MetricCatalog._split_variable_values(variables.get(variable_name, ""))) > 1
        ]
        if not varying_variable_names:
            return [(variables, "")]

        value_options = [
            MetricCatalog._split_variable_values(variables[variable_name])
            for variable_name in varying_variable_names
        ]

        variants: list[tuple[dict[str, str], str]] = []
        for values in product(*value_options):
            rendered_variables = dict(variables)
            display_parts: list[str] = []
            for variable_name, variable_value in zip(varying_variable_names, values):
                rendered_variables[variable_name] = variable_value
                display_parts.append(MetricCatalog._format_variable_label(variable_value))
            variants.append((rendered_variables, " ".join(display_parts)))
        return variants

    @staticmethod
    def _split_variable_values(raw_value: str) -> list[str]:
        values = [value.strip() for value in raw_value.split(",")]
        return [value for value in values if value] or [raw_value.strip()]

    @staticmethod
    def _format_variable_label(variable_value: str) -> str:
        if variable_value.endswith(".*"):
            base_value = variable_value[:-2]
            if base_value and all(character.isalnum() or character in {"_", "-"} for character in base_value):
                return base_value.rstrip("-_/")
        return variable_value

    @staticmethod
    def _resolve_variables(
        template: MetricQueryTemplate,
        selection: SelectionConfig,
    ) -> dict[str, str]:
        variables = dict(selection.variables)
        variables.update(selection.group_variables.get(template.group, {}))
        variables.update(selection.metric_variables.get(template.metric_id, {}))
        return variables
