"""Metric catalog and selection resolution."""

from __future__ import annotations

from dataclasses import dataclass

from ..domain import MetricDefinition, MetricGroup, MetricQueryTemplate, SelectionConfig
from ..exceptions import MetricSelectionError
from .specs import MetricGroupSpec


@dataclass(frozen=True)
class MetricCatalog:
    """Registry of all known metric templates grouped by enum values."""

    templates_by_group: dict[MetricGroup, tuple[MetricQueryTemplate, ...]]

    def __post_init__(self) -> None:
        metric_ids: set[str] = set()
        display_names: set[str] = set()

        for group, templates in self.templates_by_group.items():
            for template in templates:
                if template.group is not group:
                    raise ValueError(
                        f"Metric '{template.metric_id}' belongs to '{template.group.value}', "
                        f"but is registered in '{group.value}'."
                    )
                if template.metric_id in metric_ids:
                    raise ValueError(f"Duplicate metric id: {template.metric_id}")
                if template.display_name in display_names:
                    raise ValueError(f"Duplicate metric display name: {template.display_name}")
                metric_ids.add(template.metric_id)
                display_names.add(template.display_name)

    @classmethod
    def from_group_specs(cls, *group_specs: type[MetricGroupSpec]) -> "MetricCatalog":
        """Build a catalog from metric group specification classes."""

        return cls(
            templates_by_group={
                group_spec.group: group_spec.build_templates() for group_spec in group_specs
            }
        )

    def metrics_for_group(
        self,
        group: MetricGroup,
        variables: dict[str, str] | None = None,
    ) -> tuple[MetricDefinition, ...]:
        """Return all rendered metrics registered for the specified group."""

        return tuple(
            template.render(variables) for template in self.templates_by_group.get(group, ())
        )

    def get_metric(
        self,
        metric_id: str,
        variables: dict[str, str] | None = None,
    ) -> MetricDefinition:
        """Return a rendered metric definition by its identifier."""

        return self.get_template(metric_id).render(variables)

    def get_template(self, metric_id: str) -> MetricQueryTemplate:
        """Return a metric query template by its identifier."""

        for templates in self.templates_by_group.values():
            for template in templates:
                if template.metric_id == metric_id:
                    return template
        raise MetricSelectionError(f"Unknown metric id: {metric_id}")

    def has_metric(self, metric_id: str) -> bool:
        """Return whether the catalog contains the specified metric identifier."""

        try:
            self.get_template(metric_id)
        except MetricSelectionError:
            return False
        return True

    def resolve_selection(self, selection: SelectionConfig) -> list[MetricDefinition]:
        """Resolve the final ordered list of unique metrics from the selection config."""

        resolved: list[MetricDefinition] = []
        seen_ids: set[str] = set()

        for group in selection.groups:
            for template in self.templates_by_group.get(group, ()):
                if template.metric_id not in seen_ids:
                    resolved.append(template.render(self._resolve_variables(template, selection)))
                    seen_ids.add(template.metric_id)

        for metric_id in selection.metric_ids:
            template = self.get_template(metric_id)
            if template.metric_id not in seen_ids:
                resolved.append(template.render(self._resolve_variables(template, selection)))
                seen_ids.add(template.metric_id)

        if not resolved:
            raise MetricSelectionError("Metric selection resolved to an empty metric list.")

        return resolved

    @staticmethod
    def _resolve_variables(
        template: MetricQueryTemplate,
        selection: SelectionConfig,
    ) -> dict[str, str]:
        variables = dict(selection.variables)
        variables.update(selection.group_variables.get(template.group, {}))
        variables.update(selection.metric_variables.get(template.metric_id, {}))
        return variables
