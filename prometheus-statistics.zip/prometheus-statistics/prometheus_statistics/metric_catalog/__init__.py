"""Metric catalog building blocks and default catalog exports."""

from .catalog import MetricCatalog
from .groups.kafka_exporter import KafkaExporterGroup
from .groups.kubernetes_containers import KubernetesContainersGroup
from .specs import MetricGroupSpec, MetricQuerySpec

DEFAULT_METRIC_CATALOG = MetricCatalog.from_group_specs(
    KubernetesContainersGroup,
    KafkaExporterGroup,
)

__all__ = [
    "DEFAULT_METRIC_CATALOG",
    "KafkaExporterGroup",
    "KubernetesContainersGroup",
    "MetricCatalog",
    "MetricGroupSpec",
    "MetricQuerySpec",
]
