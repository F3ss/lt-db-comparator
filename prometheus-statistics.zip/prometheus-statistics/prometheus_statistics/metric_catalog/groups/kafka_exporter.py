"""Kafka exporter metric group definitions."""

from __future__ import annotations

from ...domain import MetricGroup
from ..specs import MetricGroupSpec, MetricQuerySpec


class KafkaExporterGroup(MetricGroupSpec):
    """Kafka exporter metrics."""

    group = MetricGroup.KAFKA_EXPORTER

    class KafkaGroupLag(MetricQuerySpec):
        metric_id = "kafka_group_lag"
        display_name = "Kafka group lag"
        query_template = "sum(kafka_consumergroup_lag)"

    class KafkaTopicPartitions(MetricQuerySpec):
        metric_id = "kafka_topic_partitions"
        display_name = "Kafka topic partitions"
        query_template = "sum(kafka_topic_partitions)"

    queries = (KafkaGroupLag, KafkaTopicPartitions)
