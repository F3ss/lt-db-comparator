"""Kubernetes container metric group definitions."""

from __future__ import annotations

from ...domain import MetricGroup
from ..specs import MetricGroupSpec, MetricQuerySpec


class KubernetesContainersGroup(MetricGroupSpec):
    """Kubernetes container metrics filtered by namespace and pod regex."""

    group = MetricGroup.KUBERNETES_CONTAINERS
    default_variables = {
        "namespace": ".*",
        "pod_regex": ".*",
    }

    class UtilsCpu(MetricQuerySpec):
        metric_id = "utils_cpu"
        display_name = "Utils cpu"
        query_template = (
            'sum(rate(container_cpu_usage_seconds_total{namespace=~"$namespace", '
            'pod=~"$pod_regex", container="utils"}[5m]))'
        )

    class UtilsRam(MetricQuerySpec):
        metric_id = "utils_ram"
        display_name = "Utils ram"
        query_template = (
            'sum(container_memory_working_set_bytes{namespace=~"$namespace", '
            'pod=~"$pod_regex", container="utils"})'
        )

    class ApiCpu(MetricQuerySpec):
        metric_id = "api_cpu"
        display_name = "API cpu"
        query_template = (
            'sum(rate(container_cpu_usage_seconds_total{namespace=~"$namespace", '
            'pod=~"$pod_regex", container="api"}[5m]))'
        )

    class ApiRam(MetricQuerySpec):
        metric_id = "api_ram"
        display_name = "API ram"
        query_template = (
            'sum(container_memory_working_set_bytes{namespace=~"$namespace", '
            'pod=~"$pod_regex", container="api"})'
        )

    queries = (UtilsCpu, UtilsRam, ApiCpu, ApiRam)
