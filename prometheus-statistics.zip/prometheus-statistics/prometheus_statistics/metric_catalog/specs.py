"""Base specification classes for metric groups and query templates."""

from __future__ import annotations

from typing import ClassVar

from ..domain import MetricGroup, MetricQueryTemplate


class MetricQuerySpec:
    """Base class for a reusable metric query template."""

    metric_id: ClassVar[str] = ""
    display_name: ClassVar[str] = ""
    query_template: ClassVar[str] = ""
    default_variables: ClassVar[dict[str, str]] = {}

    @classmethod
    def build_template(
        cls,
        *,
        group: MetricGroup,
        inherited_defaults: dict[str, str] | None = None,
    ) -> MetricQueryTemplate:
        """Build a concrete template instance for the given metric group."""

        if not cls.metric_id:
            raise ValueError(f"{cls.__name__} must define 'metric_id'.")
        if not cls.display_name:
            raise ValueError(f"{cls.__name__} must define 'display_name'.")
        if not cls.query_template:
            raise ValueError(f"{cls.__name__} must define 'query_template'.")

        default_variables = dict(inherited_defaults or {})
        default_variables.update(cls.default_variables)
        return MetricQueryTemplate(
            metric_id=cls.metric_id,
            display_name=cls.display_name,
            group=group,
            query_template=cls.query_template,
            default_variables=default_variables,
        )


class MetricGroupSpec:
    """Base class for a metric group and its nested query definitions."""

    group: ClassVar[MetricGroup]
    default_variables: ClassVar[dict[str, str]] = {}
    queries: ClassVar[tuple[type[MetricQuerySpec], ...]] = ()

    @classmethod
    def build_templates(cls) -> tuple[MetricQueryTemplate, ...]:
        """Build all metric templates declared for the group."""

        if not cls.queries:
            raise ValueError(f"{cls.__name__} must define at least one query.")

        return tuple(
            query_spec.build_template(group=cls.group, inherited_defaults=cls.default_variables)
            for query_spec in cls.queries
        )
