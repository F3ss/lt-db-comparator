"""Command-line entry point for the statistics collector."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

from .exceptions import ConfigError, CsvFormatError, MetricSelectionError, ProviderError
from .service import StatisticsService


def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""

    parser = argparse.ArgumentParser(
        prog="prometheus_statistics",
        description="Collect metric statistics and store them in a CSV history file.",
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to the TOML configuration file.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Run the CLI and return the process exit code."""

    parser = build_parser()
    args = parser.parse_args(argv)
    service = StatisticsService()

    try:
        output_path = service.run(Path(args.config))
    except (ConfigError, MetricSelectionError) as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    except ProviderError as exc:
        print(f"Provider error: {exc}", file=sys.stderr)
        return 3
    except CsvFormatError as exc:
        print(f"CSV error: {exc}", file=sys.stderr)
        return 4
    except Exception as exc:  # pragma: no cover
        print(f"Unexpected error: {exc}", file=sys.stderr)
        return 5

    print(output_path)
    return 0

