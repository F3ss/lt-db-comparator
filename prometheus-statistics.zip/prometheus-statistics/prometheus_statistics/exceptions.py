"""Application-specific exceptions."""


class ApplicationError(Exception):
    """Base class for all application errors."""


class ConfigError(ApplicationError):
    """Raised when the configuration file is missing or invalid."""


class MetricSelectionError(ApplicationError):
    """Raised when metric selection cannot be resolved."""


class ProviderError(ApplicationError):
    """Raised when metric data cannot be fetched from the source."""


class CsvFormatError(ApplicationError):
    """Raised when the CSV history file has an invalid structure."""

