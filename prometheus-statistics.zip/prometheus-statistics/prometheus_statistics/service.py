"""Application service that orchestrates collection and CSV update."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import sys
from typing import TextIO

from .config import ConfigLoader
from .csv_history import CsvHistoryRepository
from .metric_groups import DEFAULT_METRIC_CATALOG, MetricCatalog
from .models import AppConfig, MetricRunResult
from .provider import create_provider
from .statistics import StatisticsCalculator


class StatisticsService:
    """Run a full collection iteration from config to updated CSV."""

    def __init__(
        self,
        config_loader: ConfigLoader | None = None,
        metric_catalog: MetricCatalog | None = None,
        statistics_calculator: StatisticsCalculator | None = None,
        csv_repository: CsvHistoryRepository | None = None,
        warning_stream: TextIO | None = None,
    ) -> None:
        """Initialize the service and its collaborating components."""

        catalog = metric_catalog or DEFAULT_METRIC_CATALOG
        self._metric_catalog = catalog
        self._config_loader = config_loader or ConfigLoader(catalog)
        self._statistics_calculator = statistics_calculator or StatisticsCalculator()
        self._csv_repository = csv_repository or CsvHistoryRepository()
        self._warning_stream = warning_stream or sys.stderr

    def run(self, config_path: Path) -> Path:
        """Execute a single configured collection iteration and update the CSV file."""

        config = self._config_loader.load(config_path)
        results = self._collect_results(config)
        run_label = self.format_run_label(config.run.timestamp)

        self._csv_repository.update(
            path=config.run.output_csv,
            system_name=config.run.system_name,
            run_label=run_label,
            duration_seconds=config.run.duration_seconds,
            current_results=results,
            history_columns=config.run.history_columns,
        )
        return config.run.output_csv

    def _collect_results(self, config: AppConfig) -> list[MetricRunResult]:
        metrics = self._metric_catalog.resolve_selection(config.selection)
        provider = create_provider(config.source)
        results: list[MetricRunResult] = []

        for metric in metrics:
            values = provider.fetch_metric_values(
                metric=metric,
                start=config.run.start,
                end=config.run.end,
                step_seconds=config.collection.step_seconds,
            )
            if not values:
                self._warning_stream.write(
                    f"Warning: metric '{metric.metric_id}' returned no samples.\n"
                )
            statistics = self._statistics_calculator.calculate(values)
            results.append(MetricRunResult(metric=metric, statistics=statistics))

        return results

    @staticmethod
    def format_run_label(timestamp: int) -> str:
        """Format the run timestamp for the CSV header."""

        return datetime.fromtimestamp(timestamp).strftime("%d.%m.%y T %H:%M")

