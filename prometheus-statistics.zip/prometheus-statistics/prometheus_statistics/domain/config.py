"""Configuration-related domain models."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .enums import MetricGroup, SourceKind


@dataclass(frozen=True)
class RunConfig:
    """Runtime settings for a single collection iteration."""

    system_name: str
    timestamp: int
    start: int
    end: int
    history_columns: int = 10
    output_csv: Path = field(default_factory=Path)

    @property
    def duration_seconds(self) -> int:
        """Return the iteration duration in seconds."""

        return self.end - self.start


@dataclass(frozen=True)
class CollectionConfig:
    """Settings that control how metric samples are collected."""

    step_seconds: int


@dataclass(frozen=True)
class SourceConfig:
    """Settings required to connect to the metric source."""

    kind: SourceKind
    base_url: str
    timeout_seconds: int


@dataclass(frozen=True)
class SelectionConfig:
    """Selection of metric groups and explicit metric identifiers."""

    groups: list[MetricGroup]
    metric_ids: list[str]
    variables: dict[str, str] = field(default_factory=dict)
    group_variables: dict[MetricGroup, dict[str, str]] = field(default_factory=dict)
    metric_variables: dict[str, dict[str, str]] = field(default_factory=dict)


@dataclass(frozen=True)
class AppConfig:
    """Top-level application configuration."""

    run: RunConfig
    collection: CollectionConfig
    source: SourceConfig
    selection: SelectionConfig
