"""Core enumerations for configuration and metrics."""

from __future__ import annotations

from enum import Enum


class MetricGroup(str, Enum):
    """Known metric groups."""

    KUBERNETES_CONTAINERS = "kubernetes_containers"
    KAFKA_EXPORTER = "kafka_exporter"


class SourceKind(str, Enum):
    """Supported metric source kinds."""

    PROMETHEUS_HTTP = "prometheus_http"


class AggregateKind(str, Enum):
    """Supported aggregate kinds and their output order."""

    P90 = "p90"
    P95 = "p95"
    P99 = "p99"
    MAX = "max"
    MIN = "min"

    @classmethod
    def ordered(cls) -> tuple["AggregateKind", ...]:
        """Return aggregate kinds in the fixed CSV row order."""

        return (cls.P90, cls.P95, cls.P99, cls.MAX, cls.MIN)
