"""Domain-level statistics calculation utilities."""

from __future__ import annotations

import math
from collections.abc import Sequence

from .metrics import MetricStatistics


class StatisticsCalculator:
    """Calculate percentiles and extremums for a metric time series."""

    def calculate(self, values: Sequence[float]) -> MetricStatistics:
        """Calculate all supported aggregates for the given numeric values."""

        cleaned_values = [float(value) for value in values if math.isfinite(value)]
        if not cleaned_values:
            return MetricStatistics()

        sorted_values = sorted(cleaned_values)
        return MetricStatistics(
            p90=self._percentile(sorted_values, 0.90),
            p95=self._percentile(sorted_values, 0.95),
            p99=self._percentile(sorted_values, 0.99),
            max_value=max(sorted_values),
            min_value=min(sorted_values),
        )

    def _percentile(self, sorted_values: Sequence[float], percentile: float) -> float:
        if not sorted_values:
            raise ValueError("Percentile cannot be calculated for an empty sequence.")

        if len(sorted_values) == 1:
            return float(sorted_values[0])

        position = (len(sorted_values) - 1) * percentile
        lower_index = math.floor(position)
        upper_index = math.ceil(position)
        lower_value = float(sorted_values[lower_index])
        upper_value = float(sorted_values[upper_index])

        if lower_index == upper_index:
            return lower_value

        fraction = position - lower_index
        return lower_value + (upper_value - lower_value) * fraction
