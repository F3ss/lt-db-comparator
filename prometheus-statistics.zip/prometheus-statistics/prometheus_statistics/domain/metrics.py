"""Metric-related domain models."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from string import Template

from ..exceptions import MetricSelectionError
from .enums import AggregateKind, MetricGroup


@dataclass(frozen=True)
class MetricDefinition:
    """Description of a single metric and its source query."""

    metric_id: str
    display_name: str
    group: MetricGroup
    query: str


@dataclass(frozen=True)
class MetricQueryTemplate:
    """Reusable query template that can be rendered with runtime variables."""

    metric_id: str
    display_name: str
    group: MetricGroup
    query_template: str
    default_variables: dict[str, str] = field(default_factory=dict)

    def render(self, variables: Mapping[str, str] | None = None) -> MetricDefinition:
        """Render the final query by merging defaults with runtime variables."""

        merged_variables = dict(self.default_variables)
        if variables is not None:
            merged_variables.update(variables)

        missing_variables = [
            variable_name
            for variable_name in self.required_variables()
            if variable_name not in merged_variables
        ]
        if missing_variables:
            missing_list = ", ".join(missing_variables)
            raise MetricSelectionError(
                f"Metric '{self.metric_id}' requires query variables: {missing_list}."
            )

        query = Template(self.query_template).substitute(merged_variables)
        return MetricDefinition(
            metric_id=self.metric_id,
            display_name=self.display_name,
            group=self.group,
            query=query,
        )

    def required_variables(self) -> tuple[str, ...]:
        """Return distinct template variable names required by the query."""

        required: list[str] = []
        for match in Template.pattern.finditer(self.query_template):
            variable_name = match.group("named") or match.group("braced")
            if variable_name and variable_name not in required:
                required.append(variable_name)
        return tuple(required)


@dataclass(frozen=True)
class MetricStatistics:
    """Calculated aggregate values for a metric."""

    p90: float | None = None
    p95: float | None = None
    p99: float | None = None
    max_value: float | None = None
    min_value: float | None = None

    def as_mapping(self) -> dict[AggregateKind, float | None]:
        """Return aggregate values mapped by their kinds."""

        return {
            AggregateKind.P90: self.p90,
            AggregateKind.P95: self.p95,
            AggregateKind.P99: self.p99,
            AggregateKind.MAX: self.max_value,
            AggregateKind.MIN: self.min_value,
        }


@dataclass(frozen=True)
class MetricRunResult:
    """Collected and calculated result for a single metric."""

    metric: MetricDefinition
    statistics: MetricStatistics
