"""Read, merge and write CSV history documents."""

from __future__ import annotations

import csv
import os
from dataclasses import dataclass
from pathlib import Path
import tempfile

from ..domain import AggregateKind, MetricRunResult, MetricStatistics
from ..exceptions import CsvFormatError


@dataclass(frozen=True)
class CsvMetricBlock:
    """CSV representation of a single metric across all history columns."""

    metric_name: str
    aggregate_rows: dict[AggregateKind, list[str]]


@dataclass(frozen=True)
class CsvHistoryDocument:
    """In-memory representation of the CSV history file."""

    system_name: str
    run_labels: list[str]
    durations: list[str]
    metric_blocks: list[CsvMetricBlock]

    def to_rows(self) -> list[list[str]]:
        """Render the document into rows ready for CSV serialization."""

        if len(self.run_labels) != len(self.durations):
            raise CsvFormatError("CSV document has mismatched header and duration column counts.")

        rows: list[list[str]] = [["Имя метрики", *self.run_labels], [self.system_name, *self.durations]]
        expected_width = len(self.run_labels)

        for block in self.metric_blocks:
            for index, aggregate_kind in enumerate(AggregateKind.ordered()):
                aggregate_values = block.aggregate_rows.get(aggregate_kind)
                if aggregate_values is None:
                    raise CsvFormatError(
                        f"Metric '{block.metric_name}' misses aggregate '{aggregate_kind.value}'."
                    )
                if len(aggregate_values) != expected_width:
                    raise CsvFormatError(
                        f"Metric '{block.metric_name}' has inconsistent history width."
                    )

                metric_cell = block.metric_name if index == 0 else ""
                rows.append([metric_cell, *aggregate_values])

        return rows


class CsvHistoryRepository:
    """Repository that loads, merges and persists CSV history files."""

    HEADER_TITLE = "Имя метрики"
    MISSING_VALUE = "null"

    def load(self, path: Path) -> CsvHistoryDocument | None:
        """Load an existing CSV history document or return `None` if the file does not exist."""

        if not path.exists():
            return None

        with path.open("r", encoding="utf-8-sig", newline="") as file_obj:
            rows = list(csv.reader(file_obj))

        if not rows:
            raise CsvFormatError(f"CSV file is empty: {path}")

        normalized_rows = self._normalize_rows(rows)
        if len(normalized_rows) < 2:
            raise CsvFormatError("CSV file must contain at least a header and a system row.")

        header_row = normalized_rows[0]
        system_row = normalized_rows[1]
        if header_row[0].strip() != self.HEADER_TITLE:
            raise CsvFormatError(
                f"CSV header first cell must be '{self.HEADER_TITLE}', got '{header_row[0]}'."
            )
        if not system_row[0].strip():
            raise CsvFormatError("CSV system row must contain the system name in the first column.")

        metric_rows = normalized_rows[2:]
        block_size = len(AggregateKind.ordered())
        if len(metric_rows) % block_size != 0:
            raise CsvFormatError(
                f"CSV metric rows count must be divisible by {block_size}, got {len(metric_rows)}."
            )

        run_labels = header_row[1:]
        durations = system_row[1:]
        if len(run_labels) != len(durations):
            raise CsvFormatError("CSV header and duration rows must have the same number of columns.")

        metric_blocks: list[CsvMetricBlock] = []
        seen_metric_names: set[str] = set()

        for offset in range(0, len(metric_rows), block_size):
            rows_slice = metric_rows[offset : offset + block_size]
            metric_name = rows_slice[0][0].strip()
            if not metric_name:
                raise CsvFormatError("The first row of a metric block must contain the metric name.")
            if metric_name in seen_metric_names:
                raise CsvFormatError(f"Duplicate metric block in CSV: '{metric_name}'.")

            aggregate_rows: dict[AggregateKind, list[str]] = {}
            for index, aggregate_kind in enumerate(AggregateKind.ordered()):
                row = rows_slice[index]
                first_cell = row[0].strip()
                if index == 0 and first_cell != metric_name:
                    raise CsvFormatError(f"Metric block '{metric_name}' has an invalid first row.")
                if index > 0 and first_cell:
                    raise CsvFormatError(
                        f"Metric block '{metric_name}' row {index + 1} must start with an empty cell."
                    )
                aggregate_rows[aggregate_kind] = row[1:]

            metric_blocks.append(
                CsvMetricBlock(metric_name=metric_name, aggregate_rows=aggregate_rows)
            )
            seen_metric_names.add(metric_name)

        return CsvHistoryDocument(
            system_name=system_row[0].strip(),
            run_labels=run_labels,
            durations=durations,
            metric_blocks=metric_blocks,
        )

    def update(
        self,
        path: Path,
        system_name: str,
        run_label: str,
        duration_seconds: int,
        current_results: list[MetricRunResult],
        history_columns: int,
    ) -> CsvHistoryDocument:
        """Load, merge and save the CSV history for a single iteration."""

        existing_document = self.load(path)
        merged_document = self.merge(
            existing_document=existing_document,
            system_name=system_name,
            run_label=run_label,
            duration_seconds=duration_seconds,
            current_results=current_results,
            history_columns=history_columns,
        )
        self.save(path, merged_document)
        return merged_document

    def merge(
        self,
        existing_document: CsvHistoryDocument | None,
        system_name: str,
        run_label: str,
        duration_seconds: int,
        current_results: list[MetricRunResult],
        history_columns: int,
    ) -> CsvHistoryDocument:
        """Merge a new iteration into an existing CSV history document."""

        if history_columns < 1:
            raise CsvFormatError("History columns limit must be greater than or equal to 1.")

        if existing_document is not None and existing_document.system_name != system_name:
            raise CsvFormatError(
                "Existing CSV belongs to another system: "
                f"'{existing_document.system_name}' != '{system_name}'."
            )

        existing_document = existing_document or CsvHistoryDocument(
            system_name=system_name,
            run_labels=[],
            durations=[],
            metric_blocks=[],
        )

        current_by_name: dict[str, MetricStatistics] = {}
        current_order: list[str] = []
        for result in current_results:
            metric_name = result.metric.display_name
            if metric_name in current_by_name:
                raise CsvFormatError(f"Duplicate metric in current results: '{metric_name}'.")
            current_by_name[metric_name] = result.statistics
            current_order.append(metric_name)

        existing_by_name = {
            metric_block.metric_name: metric_block for metric_block in existing_document.metric_blocks
        }
        final_order = [block.metric_name for block in existing_document.metric_blocks]
        for metric_name in current_order:
            if metric_name not in existing_by_name:
                final_order.append(metric_name)

        old_width = len(existing_document.run_labels)
        new_run_labels = [run_label, *existing_document.run_labels][:history_columns]
        new_durations = [str(duration_seconds), *existing_document.durations][:history_columns]

        metric_blocks: list[CsvMetricBlock] = []
        for metric_name in final_order:
            existing_block = existing_by_name.get(metric_name)
            if existing_block is None:
                existing_rows = {
                    aggregate_kind: [self.MISSING_VALUE] * old_width
                    for aggregate_kind in AggregateKind.ordered()
                }
            else:
                existing_rows = existing_block.aggregate_rows

            if metric_name in current_by_name:
                current_values = self._statistics_to_strings(current_by_name[metric_name])
            else:
                current_values = {
                    aggregate_kind: self.MISSING_VALUE for aggregate_kind in AggregateKind.ordered()
                }

            aggregate_rows: dict[AggregateKind, list[str]] = {}
            for aggregate_kind in AggregateKind.ordered():
                previous_values = existing_rows[aggregate_kind]
                aggregate_rows[aggregate_kind] = [
                    current_values[aggregate_kind],
                    *previous_values,
                ][:history_columns]

            metric_blocks.append(
                CsvMetricBlock(metric_name=metric_name, aggregate_rows=aggregate_rows)
            )

        return CsvHistoryDocument(
            system_name=system_name,
            run_labels=new_run_labels,
            durations=new_durations,
            metric_blocks=metric_blocks,
        )

    def save(self, path: Path, document: CsvHistoryDocument) -> None:
        """Persist the CSV history document using an atomic file replace."""

        rows = document.to_rows()
        path.parent.mkdir(parents=True, exist_ok=True)

        fd, temporary_path = tempfile.mkstemp(
            prefix=f"{path.stem}_",
            suffix=path.suffix or ".csv",
            dir=path.parent,
            text=True,
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as file_obj:
                writer = csv.writer(file_obj)
                writer.writerows(rows)
            os.replace(temporary_path, path)
        except Exception:
            try:
                os.unlink(temporary_path)
            except FileNotFoundError:
                pass
            raise

    @staticmethod
    def _normalize_rows(rows: list[list[str]]) -> list[list[str]]:
        max_width = max(len(row) for row in rows)
        return [row + [""] * (max_width - len(row)) for row in rows]

    @staticmethod
    def _statistics_to_strings(statistics: MetricStatistics) -> dict[AggregateKind, str]:
        return {
            aggregate_kind: CsvHistoryRepository._format_value(value)
            for aggregate_kind, value in statistics.as_mapping().items()
        }

    @staticmethod
    def _format_value(value: float | None) -> str:
        if value is None:
            return ""
        return format(value, ".10g")
