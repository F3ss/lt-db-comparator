"""Domain models used across the application."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class MetricGroup(str, Enum):
    """Known metric groups."""

    KUBERNETES_CONTAINERS = "kubernetes_containers"
    KAFKA_EXPORTER = "kafka_exporter"


class SourceKind(str, Enum):
    """Supported metric source kinds."""

    PROMETHEUS_HTTP = "prometheus_http"


class AggregateKind(str, Enum):
    """Supported aggregate kinds and their output order."""

    P90 = "p90"
    P95 = "p95"
    P99 = "p99"
    MAX = "max"
    MIN = "min"

    @classmethod
    def ordered(cls) -> tuple["AggregateKind", ...]:
        """Return aggregate kinds in the fixed CSV row order."""

        return (cls.P90, cls.P95, cls.P99, cls.MAX, cls.MIN)


@dataclass(frozen=True)
class RunConfig:
    """Runtime settings for a single collection iteration."""

    system_name: str
    timestamp: int
    start: int
    end: int
    history_columns: int = 10
    output_csv: Path = field(default_factory=Path)

    @property
    def duration_seconds(self) -> int:
        """Return the iteration duration in seconds."""

        return self.end - self.start


@dataclass(frozen=True)
class CollectionConfig:
    """Settings that control how metric samples are collected."""

    step_seconds: int


@dataclass(frozen=True)
class SourceConfig:
    """Settings required to connect to the metric source."""

    kind: SourceKind
    base_url: str
    timeout_seconds: int


@dataclass(frozen=True)
class SelectionConfig:
    """Selection of metric groups and explicit metric identifiers."""

    groups: list[MetricGroup]
    metric_ids: list[str]


@dataclass(frozen=True)
class AppConfig:
    """Top-level application configuration."""

    run: RunConfig
    collection: CollectionConfig
    source: SourceConfig
    selection: SelectionConfig


@dataclass(frozen=True)
class MetricDefinition:
    """Description of a single metric and its source query."""

    metric_id: str
    display_name: str
    group: MetricGroup
    query: str


@dataclass(frozen=True)
class MetricStatistics:
    """Calculated aggregate values for a metric."""

    p90: float | None = None
    p95: float | None = None
    p99: float | None = None
    max_value: float | None = None
    min_value: float | None = None

    def as_mapping(self) -> dict[AggregateKind, float | None]:
        """Return aggregate values mapped by their kinds."""

        return {
            AggregateKind.P90: self.p90,
            AggregateKind.P95: self.p95,
            AggregateKind.P99: self.p99,
            AggregateKind.MAX: self.max_value,
            AggregateKind.MIN: self.min_value,
        }


@dataclass(frozen=True)
class MetricRunResult:
    """Collected and calculated result for a single metric."""

    metric: MetricDefinition
    statistics: MetricStatistics

