"""Tools for collecting Prometheus-based metric statistics into CSV history."""

