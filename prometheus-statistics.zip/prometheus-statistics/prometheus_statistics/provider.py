"""Metric source providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable
import json
import math
from urllib import error, parse, request

from .exceptions import ProviderError
from .models import MetricDefinition, SourceConfig, SourceKind


class DataProvider(ABC):
    """Abstract metric source provider."""

    @abstractmethod
    def fetch_metric_values(
        self, metric: MetricDefinition, start: int, end: int, step_seconds: int
    ) -> list[float]:
        """Fetch the raw numeric sample values for the specified metric."""


class PrometheusHttpProvider(DataProvider):
    """Fetch metric data from the Prometheus HTTP API."""

    def __init__(self, base_url: str, timeout_seconds: int) -> None:
        """Initialize the provider with the Prometheus base URL and timeout."""

        self._base_url = base_url.rstrip("/")
        self._timeout_seconds = timeout_seconds

    def fetch_metric_values(
        self, metric: MetricDefinition, start: int, end: int, step_seconds: int
    ) -> list[float]:
        """Fetch metric samples using the Prometheus `query_range` endpoint."""

        params = parse.urlencode(
            {
                "query": metric.query,
                "start": start,
                "end": end,
                "step": step_seconds,
            }
        )
        url = f"{self._base_url}/api/v1/query_range?{params}"

        try:
            with request.urlopen(url, timeout=self._timeout_seconds) as response:
                payload = json.load(response)
        except error.HTTPError as exc:
            raise ProviderError(
                f"Prometheus returned HTTP {exc.code} for metric '{metric.metric_id}'."
            ) from exc
        except error.URLError as exc:
            raise ProviderError(
                f"Prometheus request failed for metric '{metric.metric_id}': {exc.reason}"
            ) from exc
        except TimeoutError as exc:
            raise ProviderError(
                f"Prometheus request timed out for metric '{metric.metric_id}'."
            ) from exc
        except json.JSONDecodeError as exc:
            raise ProviderError(
                f"Prometheus returned invalid JSON for metric '{metric.metric_id}'."
            ) from exc

        return self._extract_values(metric, payload)

    def _extract_values(self, metric: MetricDefinition, payload: object) -> list[float]:
        if not isinstance(payload, dict):
            raise ProviderError(f"Prometheus payload for '{metric.metric_id}' must be an object.")

        if payload.get("status") != "success":
            raise ProviderError(f"Prometheus query failed for metric '{metric.metric_id}'.")

        data = payload.get("data")
        if not isinstance(data, dict):
            raise ProviderError(f"Prometheus payload for '{metric.metric_id}' misses 'data'.")

        result = data.get("result")
        if not isinstance(result, list):
            raise ProviderError(f"Prometheus payload for '{metric.metric_id}' misses 'result'.")

        values: list[float] = []
        for series in result:
            values.extend(self._extract_series_values(metric, series))

        return values

    def _extract_series_values(self, metric: MetricDefinition, series: object) -> Iterable[float]:
        if not isinstance(series, dict):
            raise ProviderError(f"Series payload for '{metric.metric_id}' must be an object.")

        raw_values = series.get("values")
        if not isinstance(raw_values, list):
            raise ProviderError(f"Series payload for '{metric.metric_id}' misses 'values'.")

        values: list[float] = []
        for pair in raw_values:
            if not isinstance(pair, list) or len(pair) < 2:
                raise ProviderError(
                    f"Series values for '{metric.metric_id}' must be [timestamp, value] pairs."
                )
            try:
                numeric_value = float(pair[1])
            except (TypeError, ValueError) as exc:
                raise ProviderError(
                    f"Series contains a non-numeric value for '{metric.metric_id}'."
                ) from exc

            if math.isfinite(numeric_value):
                values.append(numeric_value)

        return values


def create_provider(config: SourceConfig) -> DataProvider:
    """Create a concrete provider for the configured source kind."""

    if config.kind is SourceKind.PROMETHEUS_HTTP:
        return PrometheusHttpProvider(
            base_url=config.base_url,
            timeout_seconds=config.timeout_seconds,
        )
    raise ProviderError(f"Unsupported source kind: {config.kind.value}")
