"""Tests for configuration loading."""

from __future__ import annotations

from pathlib import Path
import tempfile
import textwrap
import unittest

from prometheus_statistics.config import ConfigLoader
from prometheus_statistics.exceptions import ConfigError


class ConfigLoaderTests(unittest.TestCase):
    """Verify TOML loading and validation."""

    def setUp(self) -> None:
        self.loader = ConfigLoader()

    def test_load_resolves_relative_output_path_against_config_directory(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "config.toml"
            config_path.write_text(
                textwrap.dedent(
                    """
                    [run]
                    system_name = "billing-service"
                    timestamp = 1774596600
                    start = 1774596000
                    end = 1774596600
                    history_columns = 10
                    output_csv = "artifacts/statistics.csv"

                    [collection]
                    step_seconds = 15

                    [source]
                    kind = "prometheus_http"
                    base_url = "http://localhost:9090"
                    timeout_seconds = 10

                    [selection]
                    groups = ["kubernetes_containers"]
                    metric_ids = ["kafka_group_lag"]
                    """
                ).strip(),
                encoding="utf-8",
            )

            config = self.loader.load(config_path)

            self.assertEqual(config.run.output_csv, Path(temp_dir) / "artifacts" / "statistics.csv")
            self.assertEqual(config.run.duration_seconds, 600)

    def test_load_rejects_unknown_metric_id(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "config.toml"
            config_path.write_text(
                textwrap.dedent(
                    """
                    [run]
                    system_name = "billing-service"
                    timestamp = 1774596600
                    start = 1774596000
                    end = 1774596600
                    output_csv = "statistics.csv"

                    [collection]
                    step_seconds = 15

                    [source]
                    kind = "prometheus_http"
                    base_url = "http://localhost:9090"

                    [selection]
                    metric_ids = ["missing_metric"]
                    """
                ).strip(),
                encoding="utf-8",
            )

            with self.assertRaises(ConfigError):
                self.loader.load(config_path)


if __name__ == "__main__":
    unittest.main()

