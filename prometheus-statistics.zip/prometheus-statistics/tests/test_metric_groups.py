"""Tests for the metric catalog."""

from __future__ import annotations

import unittest

from prometheus_statistics.domain import MetricGroup, SelectionConfig
from prometheus_statistics.metric_catalog import DEFAULT_METRIC_CATALOG


class MetricCatalogTests(unittest.TestCase):
    """Verify metric resolution from groups and explicit identifiers."""

    def test_resolve_selection_preserves_order_and_uniqueness(self) -> None:
        selection = SelectionConfig(
            groups=[MetricGroup.KUBERNETES_CONTAINERS],
            metric_ids=["utils_cpu", "kafka_group_lag"],
        )

        metrics = DEFAULT_METRIC_CATALOG.resolve_selection(selection)

        self.assertEqual(
            [metric.metric_id for metric in metrics],
            ["utils_cpu", "utils_ram", "api_cpu", "api_ram", "kafka_group_lag"],
        )

    def test_resolve_selection_renders_group_and_metric_variables(self) -> None:
        selection = SelectionConfig(
            groups=[MetricGroup.KUBERNETES_CONTAINERS],
            metric_ids=[],
            variables={
                "namespace": "shared-namespace",
                "pod_regex": "shared-.*",
            },
            group_variables={
                MetricGroup.KUBERNETES_CONTAINERS: {
                    "namespace": "billing",
                }
            },
            metric_variables={
                "utils_cpu": {
                    "pod_regex": "billing-utils-.*",
                }
            },
        )

        metrics = DEFAULT_METRIC_CATALOG.resolve_selection(selection)
        metrics_by_id = {metric.metric_id: metric for metric in metrics}

        self.assertEqual(
            metrics_by_id["utils_cpu"].query,
            (
                'sum(rate(container_cpu_usage_seconds_total{namespace=~"billing", '
                'pod=~"billing-utils-.*", container="utils"}[5m]))'
            ),
        )
        self.assertEqual(
            metrics_by_id["utils_ram"].query,
            (
                'sum(container_memory_working_set_bytes{namespace=~"billing", '
                'pod=~"shared-.*", container="utils"})'
            ),
        )


if __name__ == "__main__":
    unittest.main()
