"""Tests for the metric catalog."""

from __future__ import annotations

import unittest

from prometheus_statistics.metric_groups import DEFAULT_METRIC_CATALOG
from prometheus_statistics.models import MetricGroup, SelectionConfig


class MetricCatalogTests(unittest.TestCase):
    """Verify metric resolution from groups and explicit identifiers."""

    def test_resolve_selection_preserves_order_and_uniqueness(self) -> None:
        selection = SelectionConfig(
            groups=[MetricGroup.KUBERNETES_CONTAINERS],
            metric_ids=["utils_cpu", "kafka_group_lag"],
        )

        metrics = DEFAULT_METRIC_CATALOG.resolve_selection(selection)

        self.assertEqual(
            [metric.metric_id for metric in metrics],
            ["utils_cpu", "utils_ram", "api_cpu", "api_ram", "kafka_group_lag"],
        )


if __name__ == "__main__":
    unittest.main()

