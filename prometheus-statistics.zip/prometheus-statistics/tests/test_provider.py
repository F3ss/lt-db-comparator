"""Tests for Prometheus provider behavior."""

from __future__ import annotations

from io import BytesIO
import unittest
from unittest import mock

from prometheus_statistics.exceptions import ProviderError
from prometheus_statistics.domain import MetricDefinition, MetricGroup
from prometheus_statistics.infrastructure.provider import PrometheusHttpProvider


class FakeResponse(BytesIO):
    """Simple context-managed byte stream for mocking HTTP responses."""

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class PrometheusHttpProviderTests(unittest.TestCase):
    """Verify Prometheus response parsing."""

    def setUp(self) -> None:
        self.provider = PrometheusHttpProvider("http://localhost:9090", timeout_seconds=10)
        self.metric = MetricDefinition(
            metric_id="utils_cpu",
            display_name="Utils cpu",
            group=MetricGroup.KUBERNETES_CONTAINERS,
            query="up",
        )

    def test_fetch_metric_values_returns_numeric_samples(self) -> None:
        payload = (
            b'{"status":"success","data":{"resultType":"matrix","result":['
            b'{"values":[[1774596000,"1.5"],[1774596015,"2.5"]]}]}}'
        )

        with mock.patch(
            "prometheus_statistics.infrastructure.provider.request.urlopen",
            return_value=FakeResponse(payload),
        ):
            values = self.provider.fetch_metric_values(self.metric, 1, 2, 15)

        self.assertEqual(values, [1.5, 2.5])

    def test_fetch_metric_values_rejects_invalid_payload(self) -> None:
        payload = b'{"status":"success","data":{"result":"broken"}}'

        with mock.patch(
            "prometheus_statistics.infrastructure.provider.request.urlopen",
            return_value=FakeResponse(payload),
        ):
            with self.assertRaises(ProviderError):
                self.provider.fetch_metric_values(self.metric, 1, 2, 15)


if __name__ == "__main__":
    unittest.main()
