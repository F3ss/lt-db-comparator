"""Optional end-to-end test against a real Prometheus instance."""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import tomllib
import unittest
from typing import Any

from prometheus_statistics.application.service import StatisticsService
from prometheus_statistics.infrastructure.config_loader import ConfigLoader
from prometheus_statistics.infrastructure.csv_history import CsvHistoryRepository
from prometheus_statistics.metric_catalog import DEFAULT_METRIC_CATALOG


class RealPrometheusEndToEndTests(unittest.TestCase):
    """Run the CLI against a live Prometheus using an external TOML config."""

    def test_cli_runs_end_to_end_against_real_prometheus(self) -> None:
        config_env = os.environ.get("PROMETHEUS_E2E_CONFIG")
        if not config_env:
            self.skipTest(
                "Set PROMETHEUS_E2E_CONFIG to a real TOML config file to run this test."
            )

        source_config_path = Path(config_env).expanduser().resolve()
        self.assertTrue(
            source_config_path.is_file(),
            f"PROMETHEUS_E2E_CONFIG does not point to a file: {source_config_path}",
        )

        repo_root = Path(__file__).resolve().parents[1]
        raw_config = self._load_toml(source_config_path)

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            output_csv = temp_path / "statistics.csv"
            test_config = deepcopy(raw_config)
            test_config["run"]["output_csv"] = output_csv.as_posix()

            test_config_path = temp_path / "config.toml"
            test_config_path.write_text(self._dump_toml(test_config), encoding="utf-8")

            run = subprocess.run(
                [sys.executable, "-m", "prometheus_statistics", "--config", str(test_config_path)],
                cwd=repo_root,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertEqual(run.stdout.strip(), str(output_csv))

            loaded_config = ConfigLoader().load(test_config_path)
            expected_metrics = DEFAULT_METRIC_CATALOG.resolve_selection(loaded_config.selection)
            document = CsvHistoryRepository().load(output_csv)

        self.assertIsNotNone(document)
        assert document is not None
        self.assertEqual(document.system_name, loaded_config.run.system_name)
        self.assertEqual(
            document.run_labels,
            [StatisticsService.format_run_label(loaded_config.run.timestamp)],
        )
        self.assertEqual(document.durations, [str(loaded_config.run.duration_seconds)])
        self.assertEqual(
            [block.metric_name for block in document.metric_blocks],
            [metric.display_name for metric in expected_metrics],
        )

    @staticmethod
    def _load_toml(path: Path) -> dict[str, Any]:
        with path.open("rb") as file_obj:
            data = tomllib.load(file_obj)
        if not isinstance(data, dict):
            raise AssertionError("The provided config must have a TOML table at the root.")
        return data

    @classmethod
    def _dump_toml(cls, data: Mapping[str, Any]) -> str:
        lines: list[str] = []
        cls._append_table(lines, None, data)
        return "\n".join(lines) + "\n"

    @classmethod
    def _append_table(
        cls,
        lines: list[str],
        prefix: str | None,
        table: Mapping[str, Any],
    ) -> None:
        scalar_lines: list[str] = []
        nested_tables: list[tuple[str, Mapping[str, Any]]] = []

        for key, value in table.items():
            if isinstance(value, Mapping):
                child_prefix = key if prefix is None else f"{prefix}.{key}"
                nested_tables.append((child_prefix, value))
            else:
                scalar_lines.append(f"{key} = {cls._format_value(value)}")

        if prefix is not None:
            if lines:
                lines.append("")
            lines.append(f"[{prefix}]")
        lines.extend(scalar_lines)

        for child_prefix, child_table in nested_tables:
            cls._append_table(lines, child_prefix, child_table)

    @staticmethod
    def _format_value(value: Any) -> str:
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            return repr(value)
        if isinstance(value, str):
            return json.dumps(value)
        if isinstance(value, list):
            return "[" + ", ".join(RealPrometheusEndToEndTests._format_value(item) for item in value) + "]"
        raise TypeError(f"Unsupported TOML value type: {type(value)!r}")


if __name__ == "__main__":
    unittest.main()
