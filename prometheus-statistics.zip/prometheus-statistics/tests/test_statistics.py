"""Tests for statistics calculation."""

from __future__ import annotations

import unittest

from prometheus_statistics.domain.statistics import StatisticsCalculator


class StatisticsCalculatorTests(unittest.TestCase):
    """Verify aggregate calculations."""

    def setUp(self) -> None:
        self.calculator = StatisticsCalculator()

    def test_calculate_returns_expected_percentiles(self) -> None:
        result = self.calculator.calculate([1, 2, 3, 4, 5])

        self.assertAlmostEqual(result.p90 or 0.0, 4.6)
        self.assertAlmostEqual(result.p95 or 0.0, 4.8)
        self.assertAlmostEqual(result.p99 or 0.0, 4.96)
        self.assertEqual(result.max_value, 5)
        self.assertEqual(result.min_value, 1)

    def test_calculate_returns_empty_statistics_for_empty_sequence(self) -> None:
        result = self.calculator.calculate([])

        self.assertIsNone(result.p90)
        self.assertIsNone(result.p95)
        self.assertIsNone(result.p99)
        self.assertIsNone(result.max_value)
        self.assertIsNone(result.min_value)


if __name__ == "__main__":
    unittest.main()
