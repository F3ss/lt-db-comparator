"""Full end-to-end tests for the CLI application."""

from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import threading
from urllib.parse import parse_qs, urlparse
import unittest

from prometheus_statistics.application.service import StatisticsService
from prometheus_statistics.domain import AggregateKind
from prometheus_statistics.infrastructure.csv_history import CsvHistoryRepository
from prometheus_statistics.metric_catalog import DEFAULT_METRIC_CATALOG


class PrometheusStubHandler(BaseHTTPRequestHandler):
    """Serve deterministic Prometheus `query_range` responses for tests."""

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/v1/query_range":
            self.send_error(404, "Unknown path")
            return

        params = parse_qs(parsed.query)
        query = params.get("query", [None])[0]
        start_value = params.get("start", [None])[0]
        end_value = params.get("end", [None])[0]
        step_value = params.get("step", [None])[0]

        if query is None or start_value is None or end_value is None or step_value is None:
            self.send_error(400, "Missing query parameters")
            return

        try:
            key = (query, int(start_value), int(end_value), int(step_value))
            values = self.server.responses[key]  # type: ignore[attr-defined]
        except (KeyError, ValueError):
            self.send_error(404, "Unexpected query_range request")
            return

        payload = {
            "status": "success",
            "data": {
                "resultType": "matrix",
                "result": [
                    {
                        "metric": {},
                        "values": [
                            [key[1] + index * key[3], str(value)]
                            for index, value in enumerate(values)
                        ],
                    }
                ],
            },
        }

        body = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args) -> None:
        """Silence test HTTP logs."""


class EndToEndTests(unittest.TestCase):
    """Verify the full CLI flow against a local HTTP stub server."""

    def test_cli_runs_end_to_end_and_updates_csv_history(self) -> None:
        repo_root = Path(__file__).resolve().parents[1]
        csv_repository = CsvHistoryRepository()
        cpu_query = DEFAULT_METRIC_CATALOG.get_metric(
            "utils_cpu",
            variables={
                "namespace": "billing",
                "pod_regex": "billing-utils-.*",
            },
        ).query
        ram_query = DEFAULT_METRIC_CATALOG.get_metric(
            "utils_ram",
            variables={
                "namespace": "billing",
                "pod_regex": "billing-api-.*",
            },
        ).query

        first_timestamp = 1774596600
        second_timestamp = 1774600200
        third_timestamp = 1774603800

        responses = {
            (cpu_query, 1774596000, 1774596600, 15): [1.0, 2.0, 3.0],
            (ram_query, 1774599600, 1774600200, 15): [10.0, 20.0, 30.0],
            (cpu_query, 1774603200, 1774603800, 15): [4.0, 5.0],
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            output_csv = Path(temp_dir) / "artifacts" / "statistics.csv"

            with self._run_stub_server(responses) as base_url:
                first_config = self._write_config(
                    directory=Path(temp_dir),
                    filename="first.toml",
                    base_url=base_url,
                    timestamp=first_timestamp,
                    start=1774596000,
                    end=1774596600,
                    metric_ids=["utils_cpu"],
                    group_variables={
                        "kubernetes_containers": {
                            "namespace": "billing",
                            "pod_regex": "billing-utils-.*",
                        }
                    },
                    output_csv=output_csv,
                )
                second_config = self._write_config(
                    directory=Path(temp_dir),
                    filename="second.toml",
                    base_url=base_url,
                    timestamp=second_timestamp,
                    start=1774599600,
                    end=1774600200,
                    metric_ids=["utils_ram"],
                    group_variables={
                        "kubernetes_containers": {
                            "namespace": "billing",
                            "pod_regex": "billing-api-.*",
                        }
                    },
                    output_csv=output_csv,
                )
                third_config = self._write_config(
                    directory=Path(temp_dir),
                    filename="third.toml",
                    base_url=base_url,
                    timestamp=third_timestamp,
                    start=1774603200,
                    end=1774603800,
                    metric_ids=["utils_cpu"],
                    group_variables={
                        "kubernetes_containers": {
                            "namespace": "billing",
                            "pod_regex": "billing-utils-.*",
                        }
                    },
                    output_csv=output_csv,
                )

                first_run = subprocess.run(
                    [sys.executable, "-m", "prometheus_statistics", "--config", str(first_config)],
                    cwd=repo_root,
                    text=True,
                    capture_output=True,
                    check=False,
                )
                self.assertEqual(first_run.returncode, 0, first_run.stderr)
                self.assertEqual(first_run.stdout.strip(), str(output_csv))

                second_run = subprocess.run(
                    [sys.executable, "-m", "prometheus_statistics", "--config", str(second_config)],
                    cwd=repo_root,
                    text=True,
                    capture_output=True,
                    check=False,
                )
                self.assertEqual(second_run.returncode, 0, second_run.stderr)
                self.assertEqual(second_run.stdout.strip(), str(output_csv))

                second_document = csv_repository.load(output_csv)
                self.assertIsNotNone(second_document)
                assert second_document is not None

                self.assertEqual(
                    second_document.run_labels,
                    [
                        StatisticsService.format_run_label(second_timestamp),
                        StatisticsService.format_run_label(first_timestamp),
                    ],
                )
                self.assertEqual(second_document.durations, ["600", "600"])
                self.assertEqual(
                    [block.metric_name for block in second_document.metric_blocks],
                    ["Utils cpu", "Utils ram"],
                )

                second_blocks = {
                    block.metric_name: block.aggregate_rows for block in second_document.metric_blocks
                }
                self.assertEqual(second_blocks["Utils cpu"][AggregateKind.P90], ["null", "2.8"])
                self.assertEqual(second_blocks["Utils cpu"][AggregateKind.P95], ["null", "2.9"])
                self.assertEqual(second_blocks["Utils cpu"][AggregateKind.P99], ["null", "2.98"])
                self.assertEqual(second_blocks["Utils cpu"][AggregateKind.MAX], ["null", "3"])
                self.assertEqual(second_blocks["Utils cpu"][AggregateKind.MIN], ["null", "1"])
                self.assertEqual(second_blocks["Utils ram"][AggregateKind.P90], ["28", "null"])
                self.assertEqual(second_blocks["Utils ram"][AggregateKind.P95], ["29", "null"])
                self.assertEqual(second_blocks["Utils ram"][AggregateKind.P99], ["29.8", "null"])
                self.assertEqual(second_blocks["Utils ram"][AggregateKind.MAX], ["30", "null"])
                self.assertEqual(second_blocks["Utils ram"][AggregateKind.MIN], ["10", "null"])

                third_run = subprocess.run(
                    [sys.executable, "-m", "prometheus_statistics", "--config", str(third_config)],
                    cwd=repo_root,
                    text=True,
                    capture_output=True,
                    check=False,
                )
                self.assertEqual(third_run.returncode, 0, third_run.stderr)
                self.assertEqual(third_run.stdout.strip(), str(output_csv))

            final_document = csv_repository.load(output_csv)

        self.assertIsNotNone(final_document)
        assert final_document is not None
        self.assertEqual(
            final_document.run_labels,
            [
                StatisticsService.format_run_label(third_timestamp),
                StatisticsService.format_run_label(second_timestamp),
            ],
        )
        self.assertEqual(final_document.durations, ["600", "600"])
        self.assertEqual(
            [block.metric_name for block in final_document.metric_blocks],
            ["Utils cpu", "Utils ram"],
        )

        final_blocks = {block.metric_name: block.aggregate_rows for block in final_document.metric_blocks}
        self.assertEqual(final_blocks["Utils cpu"][AggregateKind.P90], ["4.9", "null"])
        self.assertEqual(final_blocks["Utils cpu"][AggregateKind.P95], ["4.95", "null"])
        self.assertEqual(final_blocks["Utils cpu"][AggregateKind.P99], ["4.99", "null"])
        self.assertEqual(final_blocks["Utils cpu"][AggregateKind.MAX], ["5", "null"])
        self.assertEqual(final_blocks["Utils cpu"][AggregateKind.MIN], ["4", "null"])
        self.assertEqual(final_blocks["Utils ram"][AggregateKind.P90], ["null", "28"])
        self.assertEqual(final_blocks["Utils ram"][AggregateKind.P95], ["null", "29"])
        self.assertEqual(final_blocks["Utils ram"][AggregateKind.P99], ["null", "29.8"])
        self.assertEqual(final_blocks["Utils ram"][AggregateKind.MAX], ["null", "30"])
        self.assertEqual(final_blocks["Utils ram"][AggregateKind.MIN], ["null", "10"])

    @staticmethod
    def _write_config(
        directory: Path,
        filename: str,
        base_url: str,
        timestamp: int,
        start: int,
        end: int,
        metric_ids: list[str],
        group_variables: dict[str, dict[str, str]] | None,
        output_csv: Path,
    ) -> Path:
        config_path = directory / filename
        metric_id_lines = ", ".join(f'"{metric_id}"' for metric_id in metric_ids)
        group_variable_lines: list[str] = []
        for group_name, variables in (group_variables or {}).items():
            group_variable_lines.append(f"[selection.group_variables.{group_name}]")
            group_variable_lines.extend(
                f'{key} = "{value}"' for key, value in variables.items()
            )
        config_text = textwrap.dedent(
            f"""
            [run]
            system_name = "billing-service"
            timestamp = {timestamp}
            start = {start}
            end = {end}
            history_columns = 2
            output_csv = "{output_csv.as_posix()}"

            [collection]
            step_seconds = 15

            [source]
            kind = "prometheus_http"
            base_url = "{base_url}"
            timeout_seconds = 10

            [selection]
            metric_ids = [{metric_id_lines}]
            """
        ).strip()
        if group_variable_lines:
            config_text = config_text + "\n\n" + "\n".join(group_variable_lines)
        config_path.write_text(config_text, encoding="utf-8")
        return config_path

    @staticmethod
    def _run_stub_server(
        responses: dict[tuple[str, int, int, int], list[float]]
    ) -> "_ServerContext":
        return _ServerContext(responses)


class _ServerContext:
    """Context manager around a local Prometheus stub server."""

    def __init__(self, responses: dict[tuple[str, int, int, int], list[float]]) -> None:
        self._responses = responses
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def __enter__(self) -> str:
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), PrometheusStubHandler)
        self._server.responses = self._responses  # type: ignore[attr-defined]
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        host, port = self._server.server_address
        return f"http://{host}:{port}"

    def __exit__(self, exc_type, exc, tb) -> None:
        assert self._server is not None
        self._server.shutdown()
        self._server.server_close()
        assert self._thread is not None
        self._thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
