"""Tests for CSV history merge and persistence."""

from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from prometheus_statistics.csv_history import CsvHistoryRepository
from prometheus_statistics.models import MetricDefinition, MetricGroup, MetricRunResult, MetricStatistics


def make_result(metric_id: str, display_name: str, value: float | None) -> MetricRunResult:
    """Build a metric result with identical aggregate values for testing."""

    metric = MetricDefinition(
        metric_id=metric_id,
        display_name=display_name,
        group=MetricGroup.KUBERNETES_CONTAINERS,
        query="up",
    )
    return MetricRunResult(
        metric=metric,
        statistics=MetricStatistics(
            p90=value,
            p95=value,
            p99=value,
            max_value=value,
            min_value=value,
        ),
    )


class CsvHistoryRepositoryTests(unittest.TestCase):
    """Verify CSV merge rules and file persistence."""

    def setUp(self) -> None:
        self.repository = CsvHistoryRepository()

    def test_merge_fills_old_columns_with_null_for_new_metric(self) -> None:
        first_document = self.repository.merge(
            existing_document=None,
            system_name="billing-service",
            run_label="27.03.26 T 10:00",
            duration_seconds=600,
            current_results=[make_result("utils_cpu", "Utils cpu", 10.0)],
            history_columns=10,
        )

        second_document = self.repository.merge(
            existing_document=first_document,
            system_name="billing-service",
            run_label="27.03.26 T 11:00",
            duration_seconds=600,
            current_results=[make_result("utils_ram", "Utils ram", 20.0)],
            history_columns=10,
        )

        blocks = {block.metric_name: block for block in second_document.metric_blocks}
        self.assertEqual(second_document.run_labels, ["27.03.26 T 11:00", "27.03.26 T 10:00"])
        self.assertEqual(blocks["Utils cpu"].aggregate_rows[next(iter(blocks["Utils cpu"].aggregate_rows))][0], "null")
        self.assertEqual(blocks["Utils ram"].aggregate_rows[next(iter(blocks["Utils ram"].aggregate_rows))][1], "null")

    def test_merge_fills_new_column_with_null_for_missing_metric(self) -> None:
        first_document = self.repository.merge(
            existing_document=None,
            system_name="billing-service",
            run_label="27.03.26 T 10:00",
            duration_seconds=600,
            current_results=[
                make_result("utils_cpu", "Utils cpu", 10.0),
                make_result("utils_ram", "Utils ram", 20.0),
            ],
            history_columns=10,
        )

        second_document = self.repository.merge(
            existing_document=first_document,
            system_name="billing-service",
            run_label="27.03.26 T 11:00",
            duration_seconds=600,
            current_results=[make_result("utils_cpu", "Utils cpu", 11.0)],
            history_columns=10,
        )

        blocks = {block.metric_name: block for block in second_document.metric_blocks}
        self.assertEqual(blocks["Utils cpu"].aggregate_rows[next(iter(blocks["Utils cpu"].aggregate_rows))][0], "11")
        self.assertEqual(blocks["Utils ram"].aggregate_rows[next(iter(blocks["Utils ram"].aggregate_rows))][0], "null")

    def test_save_and_load_round_trip(self) -> None:
        document = self.repository.merge(
            existing_document=None,
            system_name="billing-service",
            run_label="27.03.26 T 10:00",
            duration_seconds=600,
            current_results=[make_result("utils_cpu", "Utils cpu", 10.0)],
            history_columns=10,
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "statistics.csv"
            self.repository.save(path, document)

            loaded = self.repository.load(path)

        self.assertIsNotNone(loaded)
        assert loaded is not None
        self.assertEqual(loaded.system_name, "billing-service")
        self.assertEqual(loaded.run_labels, ["27.03.26 T 10:00"])
        self.assertEqual(loaded.metric_blocks[0].metric_name, "Utils cpu")


if __name__ == "__main__":
    unittest.main()

