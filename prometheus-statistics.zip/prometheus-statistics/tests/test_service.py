"""Integration-like tests for the application service."""

from __future__ import annotations

from io import StringIO
from pathlib import Path
import tempfile
import textwrap
import unittest
from unittest import mock

from prometheus_statistics.application.service import StatisticsService
from prometheus_statistics.infrastructure.csv_history import CsvHistoryRepository


class FakeProvider:
    """Provide predictable metric samples for tests."""

    def __init__(
        self,
        values_by_metric_id: dict[str, list[float]] | None = None,
        values_by_display_name: dict[str, list[float]] | None = None,
    ) -> None:
        self._values_by_metric_id = values_by_metric_id or {}
        self._values_by_display_name = values_by_display_name or {}

    def fetch_metric_values(self, metric, start: int, end: int, step_seconds: int) -> list[float]:
        if metric.display_name in self._values_by_display_name:
            return list(self._values_by_display_name[metric.display_name])
        return list(self._values_by_metric_id.get(metric.metric_id, []))


class StatisticsServiceTests(unittest.TestCase):
    """Verify that the service updates CSV history end-to-end."""

    def test_run_updates_csv_and_writes_warning_for_empty_series(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "config.toml"
            config_path.write_text(
                textwrap.dedent(
                    """
                    [run]
                    system_name = "billing-service"
                    timestamp = 1774596600
                    start = 1774596000
                    end = 1774596600
                    history_columns = 2
                    output_csv = "artifacts/statistics.csv"

                    [collection]
                    step_seconds = 15

                    [source]
                    kind = "prometheus_http"
                    base_url = "http://localhost:9090"
                    timeout_seconds = 10

                    [selection]
                    metric_ids = ["utils_cpu", "utils_ram"]
                    """
                ).strip(),
                encoding="utf-8",
            )

            warning_stream = StringIO()
            service = StatisticsService(warning_stream=warning_stream)
            provider = FakeProvider({"utils_cpu": [1.0, 2.0, 3.0], "utils_ram": []})

            with mock.patch(
                "prometheus_statistics.application.service.create_provider",
                return_value=provider,
            ):
                output_path = service.run(config_path)

            repository = CsvHistoryRepository()
            document = repository.load(output_path)

        self.assertIsNotNone(document)
        assert document is not None
        self.assertIn("returned no samples", warning_stream.getvalue())
        self.assertEqual(document.system_name, "billing-service")
        self.assertEqual(len(document.metric_blocks), 2)
        self.assertEqual(document.metric_blocks[0].metric_name, "Utils cpu")
        self.assertEqual(document.metric_blocks[1].metric_name, "Utils ram")
        self.assertEqual(
            document.metric_blocks[1].aggregate_rows[next(iter(document.metric_blocks[1].aggregate_rows))][0],
            "",
        )

    def test_run_collects_metric_multiple_times_for_comma_separated_variable(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "config.toml"
            config_path.write_text(
                textwrap.dedent(
                    """
                    [run]
                    system_name = "billing-service"
                    timestamp = 1774596600
                    start = 1774596000
                    end = 1774596600
                    history_columns = 2
                    output_csv = "artifacts/statistics.csv"

                    [collection]
                    step_seconds = 15

                    [source]
                    kind = "prometheus_http"
                    base_url = "http://localhost:9090"
                    timeout_seconds = 10

                    [selection]
                    metric_ids = ["utils_cpu"]

                    [selection.variables]
                    namespace = "billing"

                    [selection.metric_variables.utils_cpu]
                    pod_regex = "billing-(api|utils)-.*, account.*"
                    """
                ).strip(),
                encoding="utf-8",
            )

            warning_stream = StringIO()
            service = StatisticsService(warning_stream=warning_stream)
            provider = FakeProvider(
                values_by_display_name={
                    "Utils cpu billing-(api|utils)-.*": [1.0, 2.0, 3.0],
                    "Utils cpu account": [4.0, 5.0, 6.0],
                }
            )

            with mock.patch(
                "prometheus_statistics.application.service.create_provider",
                return_value=provider,
            ):
                output_path = service.run(config_path)

            document = CsvHistoryRepository().load(output_path)

        self.assertIsNotNone(document)
        assert document is not None
        self.assertEqual(
            [block.metric_name for block in document.metric_blocks],
            ["Utils cpu billing-(api|utils)-.*", "Utils cpu account"],
        )


if __name__ == "__main__":
    unittest.main()
